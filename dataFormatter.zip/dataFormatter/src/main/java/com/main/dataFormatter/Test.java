package com.main.dataFormatter;

public class Test {
	public static void main(String[] args) {
		System.out.println(Integer.valueOf("A50001".substring(1)));
	}
}
