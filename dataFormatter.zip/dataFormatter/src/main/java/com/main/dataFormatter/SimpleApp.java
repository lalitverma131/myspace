package com.main.dataFormatter;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.ml.feature.LabeledPoint;
import org.apache.spark.ml.linalg.Vectors;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.StructType;

public class SimpleApp {
	public static void main(String[] args) {

		SparkSession spark = SparkSession.builder().master("local[*]").appName("Simple Application").getOrCreate();

		StructType errorSchema = new StructType().add("agentId", "string").add("errorId", "string")
				.add("errorDesc", "long").add("resId", "string").add("resDesc", "string").add("timestamp", "string");

		Dataset<Row> errorData = spark.read().option("header", "true").schema(errorSchema)
				.csv("file:/C:/Users/309664/Desktop/Hackathon/Data/data.csv");

		StructType agentSchema = new StructType().add("agentId", "string").add("country", "string");

		Dataset<Row> agentData = spark.read().option("header", "true").schema(agentSchema)
				.csv("file:/C:/Users/309664/Desktop/Hackathon/Data/agent.csv");
		errorData.filter("resId != 'RESOLVED'").join(agentData, "agentId");
		System.out.println(errorData.filter("resId != 'RESOLVED'").join(agentData, "agentId").toJavaRDD()
				.map(new Function<Row, LabeledPoint>() {

					private static final long serialVersionUID = 4245895578185845142L;

					@Override
					public LabeledPoint call(Row line) throws Exception {
						spark.log().info("Inside");
						System.out.println(line.toString());
						String[] arrayOfData = line.toString().split("\t");
						LabeledPoint point = new LabeledPoint(Integer.parseInt(arrayOfData[3].substring(1)),
								Vectors.dense(Double.valueOf(arrayOfData[0].substring(1)),
										Double.valueOf(arrayOfData[1].substring(1))));
						return point;
					}
				}).count());

	}
}
