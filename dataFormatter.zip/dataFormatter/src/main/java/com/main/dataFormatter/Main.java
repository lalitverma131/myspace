package com.main.dataFormatter;

import java.util.HashMap;
import java.util.Map;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.mllib.regression.LabeledPoint;
import org.apache.spark.mllib.tree.DecisionTree;
import org.apache.spark.mllib.tree.model.DecisionTreeModel;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import scala.Tuple2;

public class Main {
	public static void main(String[] args) {
		// Starting the Spark Session not spark context
		SparkSession spark = SparkSession.builder().master("local[*]").appName("Simple Application").getOrCreate();

		// Loading the historical data from the csv
		Dataset<Row> data = spark.read().format("com.databricks.spark.csv").option("header", true)
				.load("C:\\Users\\309664\\Desktop\\data\\data.csv");
		Dataset<Row> agent = spark.read().format("com.databricks.spark.csv").option("header", true)
				.load("C:\\Users\\309664\\Desktop\\data\\agent.csv");

		// Data wrangling to transform and fetch the required fields of
		// Resolution, error and the agent
		// The labelled point would be in the format of <RESOLUTION>
		// <AGENT>:<ERROR>
		JavaRDD<LabeledPoint> mappedData = data.filter(column -> !column.isNullAt(3))
				.filter(column -> column.getString(3).matches("R[0-9]+")).join(agent, "agentId").toJavaRDD()
				.map(new Function<Row, LabeledPoint>() {
					private static final long serialVersionUID = 4245895578185845142L;

					@Override
					public LabeledPoint call(Row line) throws Exception {
						String[] arrayOfData = line.toString().replace("[", "").replace("]", "").split(",");
						LabeledPoint points = new LabeledPoint(Double.parseDouble(arrayOfData[3].substring(1)),
								org.apache.spark.mllib.linalg.Vectors.dense(Double.valueOf(arrayOfData[0].substring(1)),
										Double.valueOf(arrayOfData[1].substring(1))));
						return points;
					}
				});

		JavaRDD<LabeledPoint>[] splits = mappedData.randomSplit(new double[] { 0.7, 0.3 });
		JavaRDD<LabeledPoint> trainingData = splits[0];
		JavaRDD<LabeledPoint> testData = splits[1];

		// Set parameters.
		// Empty categoricalFeaturesInfo indicates all features are continuous.
		int numClasses = 43;
		System.out.println("----------------------------------" + numClasses);
		Map<Integer, Integer> categoricalFeaturesInfo = new HashMap<>();
		String impurity = "gini";
		int maxDepth = 2;
		int maxBins = 42;

		// Train a DecisionTree model for classification.
		DecisionTreeModel model = DecisionTree.trainClassifier(trainingData, numClasses, categoricalFeaturesInfo,
				impurity, maxDepth, maxBins);

		// Evaluate model on test instances and compute test error
		org.apache.spark.api.java.JavaPairRDD<Double, Double> predictionAndLabel = (org.apache.spark.api.java.JavaPairRDD<Double, Double>) testData
				.mapToPair(p -> new Tuple2<>(model.predict(p.features()), p.label()));
		double testErr = predictionAndLabel.filter(pl -> !pl._1().equals(pl._2())).count() / (double) testData.count();

		System.out.println("Test Error: " + testErr);
		System.out.println("Learned classification tree model:\n" + model.toDebugString());
	}
}
