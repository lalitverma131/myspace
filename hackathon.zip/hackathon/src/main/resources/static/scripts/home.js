     //1. create app module 
        var studentApp = angular.module('homeApp', []);

        //2. create controller
        studentApp.controller("homeController", function ($scope, $http) {
  
            //3. attach originalStudent model object
        	$scope.agent={country:'USA'}; 	
            $scope.originalStudent = {
                firstName: 'James',
                lastName: 'Bond',
                DoB: new Date('01/31/1980'),
                gender: 'male',
                trainingType: 'online',
                maths: false,
                physics: true,
                chemistry: true
            };
            $scope.sender={
            		pay:''
            }

            //4. copy originalStudent to student. student will be bind to a form 
            $scope.student = angular.copy($scope.originalStudent);

            //5. create submitStudentForm() function. This will be called when user submits the form
            $scope.submitStudnetForm = function () {

            	console.log("submitStudnetForm");
                // send $http request to save student
            	 $http.get('/submitData/')
                 .then(function (response) {
                     if (response.status == 200) {
                    	 
                     }
                     else {
                     }
                 });

            };

            //6. create resetForm() function. This will be called on Reset button click.  
            $scope.save = function () {
            	console.log("submitStudnetForm");
                // send $http request to save student
            	 $http.get('/submitData')
                 .then(function (response) {
                     if (response.status == 200) {
                    	 
                     }
                     else {
                     }
                 });

            
            };
            
           

    });
    