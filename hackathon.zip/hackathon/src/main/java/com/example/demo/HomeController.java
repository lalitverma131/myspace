package com.example.demo;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class HomeController {

    Logger LOGGER = Logger.getLogger(HomeController.class);

    /*@Autowired
    private MealService mealService;*/

    /**
     * search Meals for the current user by date and time ranges.
     *
     *
     * @param principal  - the current logged in user
     * @param fromDate - search from this date, including
     * @param toDate - search until this date, including
     * @param fromTime - search from this time, including
     * @param toTime - search to this time, including
     * @param pageNumber - the page number (each page has 10 entries)
     * @return - @see MealsDTO with the current page, total pages and the list of meals
     */
    @ResponseBody
    @RequestMapping(value ="/submitData",method = RequestMethod.GET)
    public String submitForData() {
    	System.out.println("Entered---------");
    	return "";
    }

  




}
